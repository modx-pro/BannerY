<?php
class PositionCreateProcessor extends modObjectCreateProcessor {
    public $classKey = 'bxPosition';
    public $languageTopics = array('bannerx:default');
    public $objectType = 'bannerx.position';
}
return 'PositionCreateProcessor';