#############################################################
#          BannerX: show banner ads on your site            #
#                                                           #
# Version: 0.2.2 pl                                         #
#                                                           #
# Author: Jeroen Kenters Web Development / www.kenters.com  #
#                                                           #
# License: GNU GENERAL PUBLIC LICENSE, Version 2            #
#############################################################

*** DESCRIPTION ***

BannerX shows banner ads on your site and keeps track of clicks

*** INSTALLATION ***

You can install this package through Package Management.

*** CONFIGURATION ***

Go to components -> BannerX
Create 1 or more positions (areas to shows ads in)
Create 1 or more ads

To show the ads, use the BannerX snippet:
[[BannerX? &position=`1` &sortby=`RAND()` &limit=`3`]]