<?php
require_once (dirname(dirname(__FILE__)) . '/bxclick.class.php');
class bxClick_mysql extends bxClick {}