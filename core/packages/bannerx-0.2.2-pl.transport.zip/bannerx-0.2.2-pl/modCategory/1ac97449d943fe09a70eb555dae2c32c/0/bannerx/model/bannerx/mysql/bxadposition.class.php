<?php
require_once (dirname(dirname(__FILE__)) . '/bxadposition.class.php');
class bxAdPosition_mysql extends bxAdPosition {}