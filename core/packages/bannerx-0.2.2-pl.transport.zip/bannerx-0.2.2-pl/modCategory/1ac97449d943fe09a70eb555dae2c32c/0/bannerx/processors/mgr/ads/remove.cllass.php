<?php
class AdRemoveProcessor extends modObjectRemoveProcessor {
    public $classKey = 'bxAd';
    public $languageTopics = array('bannerx:default');
    public $objectType = 'bannerx.ad';
}
return 'AdRemoveProcessor';