<?php
class bxAd extends xPDOSimpleObject {}