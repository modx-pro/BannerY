<?php
class bxAdPosition extends xPDOSimpleObject {}