<?php
require_once (dirname(dirname(__FILE__)) . '/bxad.class.php');
class bxAd_mysql extends bxAd {}