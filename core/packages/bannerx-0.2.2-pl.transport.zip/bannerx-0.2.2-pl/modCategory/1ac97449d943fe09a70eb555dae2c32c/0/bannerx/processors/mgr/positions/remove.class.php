<?php
class PositionRemoveProcessor extends modObjectRemoveProcessor {
    public $classKey = 'bxPosition';
    public $languageTopics = array('bannerx:default');
    public $objectType = 'bannerx.position';
}
return 'PositionRemoveProcessor';