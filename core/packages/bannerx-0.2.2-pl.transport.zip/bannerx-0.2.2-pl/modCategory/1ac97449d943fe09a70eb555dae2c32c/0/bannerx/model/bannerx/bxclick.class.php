<?php
class bxClick extends xPDOSimpleObject {}