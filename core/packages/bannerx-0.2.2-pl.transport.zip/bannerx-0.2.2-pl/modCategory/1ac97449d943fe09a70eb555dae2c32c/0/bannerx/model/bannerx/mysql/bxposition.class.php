<?php
require_once (dirname(dirname(__FILE__)) . '/bxposition.class.php');
class bxPosition_mysql extends bxPosition {}