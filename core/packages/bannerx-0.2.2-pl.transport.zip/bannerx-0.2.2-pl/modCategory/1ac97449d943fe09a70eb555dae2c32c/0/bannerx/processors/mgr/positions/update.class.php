<?php
class PositionUpdateProcessor extends modObjectUpdateProcessor {
    public $classKey = 'bxPosition';
    public $languageTopics = array('bannerx:default');
    public $objectType = 'bannerx.position';
}
return 'PositionUpdateProcessor';