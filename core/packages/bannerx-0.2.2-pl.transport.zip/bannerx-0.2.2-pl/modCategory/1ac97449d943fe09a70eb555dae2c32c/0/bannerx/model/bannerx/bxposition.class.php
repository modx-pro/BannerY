<?php
class bxPosition extends xPDOSimpleObject {}